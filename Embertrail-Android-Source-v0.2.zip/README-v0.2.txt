EMBERTRAIL v0.2
Game original WebGL 3D dengan ilustrasi lobby buatan AI. Bukan modifikasi Kingdom Guard.
Build lewat HP: unggah Embertrail-Android-Source-v0.2.zip tanpa diekstrak ke root repository GitHub. Buat .github/workflows/build-apk.yml dan tempel isi build-apk-v0.2.txt. Actions > Build Embertrail APK > Run workflow. Jika berhasil, unduh artifact Embertrail-APK dan ekstrak APK.
Belum dikompilasi atau diuji pada Android. Min SDK 26, target SDK 36 tidak menjamin kompatibilitas. Perlu internet untuk build; game memakai aset lokal dan tidak memakai permission INTERNET. Kuota GitHub Actions tergantung akun.
Backup save sebelum mengganti instalasi. Kunci debug baru pada cloud build dapat membuat APK tidak bisa memperbarui versi sebelumnya; jangan hapus aplikasi lama sebelum ekspor save.
Game telah melalui 29 pemeriksaan otomatis pada desktop Chromium/software WebGL, bukan pengujian Samsung A54. Model 3D low-poly tidak sama detailnya dengan ilustrasi lobby.
Fitur: lima hero dan skill, tiga busur, gems gratis, penukaran coin, level karakter permanen, upgrade senjata arena yang reset, peti berbasis hit, formasi regu, minimap, tutorial, efek suara, mode grafis Hemat, impor save v0.1/v0.2.
