EMBERTRAIL — THE SHATTERED REACH v0.3

WHAT THIS VERSION IS
A playable original offline browser game and Android WebView source project. It is not a Kingdom Guard modification, not a commercial-studio release, and does not use their assets. This revision intentionally uses painted 2.5D sprites on Canvas, NOT full 3D, to avoid the WebGL failures seen on the user's device and replace blocky procedural models. Illustrations are AI-generated, cropped, chroma-keyed and embedded locally.

PLAY
Open Embertrail-v0.3.html in a browser that permits local JavaScript/Canvas. No network requests or CDN are needed. HP: joystick, tap a chest/dragon to lock target, skill button on right. PC: WASD/arrows, Space skill, Esc pause. Tap the minimap for the full paused map.

NEW
- 19 embedded illustrated assets: five distinct hero silhouettes, recruit group, dragon head/body/tail, closed/open chest, bow, island, portal, crystals, trees, brazier, stone texture, sanctuary background.
- Full-body selected hero in animated lobby showcase. Gold/teal reward cards and illustrated roster.
- Expanded world in a 50x48-unit envelope; route reaches x=44/y=42. Nine connected sanctuary hubs and a full-map view. One handcrafted route/world, not nine independent maps or hundreds of levels with different artwork.
- Painted terrain islands, textured bridge decks, background currents, atmospheric haze, embers and camera following.
- Character movement uses sprite bob/lean/flip and projectile effects. These are NOT frame-by-frame skeletal walk animations or 360-degree 3D models.
- Chest damage shake, closed-to-open transition, expanding light ring and gold particle burst. Combat freezes immediately on opening.
- A mandatory choice grants either +1 to +5 recruits OR +1 to +3 bow levels, scaling with arena. It never grants both. Max squad 20 and bow Lv.20. At both caps, choose full healing to avoid a stuck dialog.
- Initial 12 HP chest still takes exactly 12 actual hits at damage 1. Weapon and squad reset next run; hero upgrades remain permanent.
- 5 skills, 3 bow loadouts, free gems 10/25/50/80/100/500/1000, 1 gem=20 coins, persistent hero level, rank/progress and imported old saves retained.
- Portals and crystals are scenery/landmarks, not interactive teleporters. The map view provides orientation, not fast travel.

ANDROID BUILD FROM HP
The supplied source ZIP keeps the name Embertrail-Android-Source-v0.2.zip for compatibility with the previous GitHub workflow. Its CONTENT is v0.3: versionCode=4, versionName=0.3.
1. Upload this NEW ZIP to the root of the same GitHub repository, replacing the previous ZIP without renaming/extracting.
2. Run the existing Build Embertrail APK workflow.
3. Download the completed Embertrail-APK artifact. The APK filename may still say v0.2-debug, while the app version inside is 0.3.
APK has NOT been built here. Android 8–16 target configuration is not a compatibility guarantee. Build tools require internet and GitHub Actions uses account quotas. The game itself has no INTERNET permission.
Cloud debug signing keys may differ between runs. EXPORT SAVE before uninstalling or replacing any installed app. Import the JSON afterward. Do not erase app/browser data without backup.

ASSET PACKAGE
Embertrail-Assets-v0.3.zip contains PNG sprites with transparency, compact WebP versions, original sheets and the sanctuary image. PNG names match their role. UI symbols are inline SVG code in the HTML; simple sound cues are synthesized by Web Audio, not separate recordings. Those sources are included in the complete HTML game inside the Android assets folder.

TESTING & LIMITS
See TEST-RESULTS.json for desktop Chromium tests at 390x844/1280x900, including all assets decoding, exact chest hits, exclusive choices, duplicate-click protection, capped rewards, paused map and persistence. This is NOT Samsung A54 hardware testing, APK testing or exhaustive game balancing.
Canvas painting is designed to avoid WebGL entirely. Actual frame rate, battery load, touch feel and all Android versions still require device testing. Kualitas Hemat reduces frame rate/effects.
The prior save key embertrail-v2 is retained. Old saves remain importable. No intentional save deletion. Editing rank/economy is possible because everything is local; no multiplayer, anti-cheat or real-money transactions.
