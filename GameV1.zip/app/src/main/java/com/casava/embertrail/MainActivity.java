package com.casava.embertrail;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Insets;
import android.view.WindowInsets;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> upload;
    private String pendingExport;
    private static final int IMPORT = 10, EXPORT = 11;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff101a1e);
        getWindow().setNavigationBarColor(0xff101a1e);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xff101a1e);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) { return true; }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Ya", (d, w) -> result.confirm())
                    .setNegativeButton("Batal", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (upload != null) upload.onReceiveValue(null);
                upload = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json");
                try { startActivityForResult(i, IMPORT); }
                catch (Exception e) { upload.onReceiveValue(null); upload = null; }
                return true;
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void exportSave(String json) {
                if (json == null || json.length() > 20000) return;
                runOnUiThread(() -> {
                    pendingExport = json;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("application/json").putExtra(Intent.EXTRA_TITLE, "embertrail-save.json");
                    try { startActivityForResult(i, EXPORT); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "Penyimpanan tidak tersedia", Toast.LENGTH_SHORT).show(); }
                });
            }
        }, "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == IMPORT && upload != null) {
            upload.onReceiveValue(result == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
            upload = null;
        }
        if (request == EXPORT && result == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Save diekspor", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Ekspor gagal", Toast.LENGTH_SHORT).show(); }
            pendingExport = null;
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("if(typeof G!=='undefined'&&G&&!G.done){pauseGame();}else{if(confirm('Tutup Embertrail?')){document.title='EXIT_EMBERTRAIL';}}", value -> {
            web.evaluateJavascript("document.title", title -> { if ("\"EXIT_EMBERTRAIL\"".equals(title)) finish(); });
        });
    }
    @Override protected void onPause() {
        if (web != null) { web.evaluateJavascript("if(typeof pauseGame==='function')pauseGame();", null); web.onPause(); }
        super.onPause();
    }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); } super.onDestroy(); }
}
